package mypack;

public class StoredProcedure {
}
